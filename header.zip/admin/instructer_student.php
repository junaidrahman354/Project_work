<?php
include 'header.php';
?>
<style>
    tr th {
        width: auto !important;
    }
</style>
<div class="container">
    <div class="row header">
        <div class="widget-heading">
            <h5 class="" style="color: black !important">Instructer Student</h5>
        </div>
        <?php include 'error.php'; ?>
        <div class="widget-content widget-content-area table_area br-6">
            <table id="html5-extension" class="table table-hover non-hover" style="width:100%">
                <thead>
                    <tr>
                        <th>Sr #</th>
                        <th>Student Name</th>
                        <th>Student Email</th>
                        <th>Instructor Name</th>
                        <th>Instructor Email</th>
                    </tr>
                </thead>
                <tbody>

                    <?php

                    $x = 1;
                    if (isset($_SESSION['instructor_id'])) {
                        $select = "select user_registration.first_name , user_registration.email, instructor_registration.first_name as ifname, instructor_registration.email as iemail from user_registration inner join instructor_registration on user_registration.instructor = instructor_registration.id where user_registration.instructor = '" . $_SESSION['instructor_id'] . "' ";
                    } else {
                        $select = "select user_registration.first_name , user_registration.email, instructor_registration.first_name as ifname, instructor_registration.email as iemail from user_registration inner join instructor_registration on user_registration.instructor = instructor_registration.id ";
                    }
                    $res = mysqli_query($con, $select);

                    while ($data = mysqli_fetch_array($res)) {

                    ?>

                        <tr>
                            <td><?= $x++ ?></td>
                            <td> <?= $data['first_name'] ?></td>
                            <td><?= $data['email'] ?></td>
                            <td><?= $data['ifname'] ?></td>
                            <td><?= $data['iemail'] ?></td>
                            <!-- <td><a href="" onClick='return confirm("Confirm to unassigned?")' class="btn btn-primary">UnAssign</a></td> -->
                        </tr>

                    <?php

                    }
                    ?>

                </tbody>
            </table>
        </div>

    </div>
</div>

<?php
include 'footer.php';
?>