<?php
if(isset($_SESSION['error'])){
	echo $_SESSION['error'];
	unset($_SESSION['error']);}
 ?>

