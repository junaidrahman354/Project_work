<?php

include 'header.php';
$update = "update user_registration set instructor = '" . $_GET['InstId'] . "' where id = '" . $_GET['id'] . "'";


$run = mysqli_query($con, $update);

if ($run) {

    $_SESSION['error'] = error('success', 'Instructor has been assigned.');

    header("location:all_user.php");
}
