<?php include "header.php"; ?>
<style>
    .thoery-form{
        box-shadow: 0px 0px 15px 0.2px rgb(212, 206, 206);
        border-radius: 6px;
        padding:20px;
        
    }
    .thoery-form label{
      font-size: 13px !important;  
    }
  
    .thoery-form input{
        height: 50px !important;
        font-size: 12px !important;
        border-radius: 7px !important;
    }
   @media (min-width:767px){
    .form-group{
        padding: 1px 30px !important;
    }
    .thoery-form{
        width: 65% !important;
        margin: auto !important;
    }
   }
   .thoery-form button{
    background-color: black !important;
    border-radius: 7px !important;
    margin-top: 1rem !important;

   }
   
</style>

<div class="container-fluid page-header p-0 my-6 mt-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="container text-center">
        <h1 class="display-4 text-white txt-sz animated slideInDown mb-4">Book driving Test</h1>
        <nav aria-label="breadcrumb animated slideInDown">
        </nav>
    </div>
</div>
<!------------------>


     <div class="container">
          <div class="row px-lg-5 mx-lg-5">
             <div class="col-12">
                <form class="thoery-form" action="">
                    <div class="form-group mt-3">
                    <span class="text-center"><b>Kind notice:</b> You can only book your driving test after you've passed your theory test.</span>
                    </div>
                   
                  <div class="form-group mt-3 mt-md-3">
                     <!-- <label class="form-control-label" for="name">Name</label> -->
                     <input type="text" name="name" class="form-control" placeholder="Enter Your Name">
                  </div>
                  <div class="form-group mt-3 mt-md-3">
                     <!-- <label class="form-control-label" for="address">Address</label> -->
                     <input type="text" name="address" class="form-control" placeholder="Enter Your Address">
                  </div>
                  <div class="form-group mt-3 mt-md-3">
                     <!-- <label class="form-control-label" for="location">Location Of The Test Center</label> -->
                     <input type="text" name="location_test_center" class="form-control" placeholder="Enter The Location Of The Test Center">
                  </div>
                  <div class="form-group mt-3 mt-md-3">
                     <!-- <label class="form-control-label" for="">Post Code</label> -->
                     <input type="text" name="postcode" class="form-control" placeholder="Enter Your Post Code">
                  </div>
                  <div class="form-group mt-3 mt-md-3">
                     <!-- <label class="form-control-label" for="">Any test center near me</label> -->
                     <input type="text" name="near_test_center" class="form-control" placeholder="Any Test Center Near Me">
                  </div>
                  <div class="form-group mt-3">
                     <label class="form-control-label" for="">A picture of your provisional licence(front)</label>
                     <input type="file" name="licence_front_pic" class="form-control" placeholder="">
                  </div>
                  <div class="form-group mt-3">
                     <label class="form-control-label" for="">A picture of your provisional licence(back)</label>
                     <input type="file" name="licence_back_pic" class="form-control" placeholder="">
                  </div>
                  <div class="form-group mt-3 mt-md-3">
                     <!-- <label class="form-control-label" for="">Add a practical test</label> -->
                     <input type="text" name="practical_test" class="form-control" placeholder="Add Theory test">
                  </div>
                  <div class="form-group mt-3 mt-md-3">
                     <!-- <label class="form-control-label" for="postcode">Cost: £112 including the booking fee</label> -->
                     <input type="text" name="cost" class="form-control" placeholder="Cost: £112 including the booking fee.">
                  </div>
                  <button class="btn btn-dark ms-md-4">Submit</button>
                </form>
              </div>        
          </div> 
     </div>




<?php include "footer.php"; ?>