Swiftmailer
===========

.. toctree::
    :maxdepth: 2

    introduction
    overview
    installing
    help-resources
    including-the-files
    messages
    headers
    sending
    plugins
    japanese
