ALTER TABLE users ALTER theme SET DEFAULT "light";
