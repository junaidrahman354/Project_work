<?php
session_start();
include_once "php/config.php";

if (isset($_SESSION['unique_id'])) {
  header("location: users.php");
}


// if() from front end
if (isset($_SESSION['fromFront'])) {
  if ($_SESSION['user_id'] && $_SESSION['fromFront'] == 'yes') {
    $select = "select * from user_registration where id = '" . $_SESSION['user_id'] . "'";
    $res = mysqli_query($conn, $select);
    $pick_data = mysqli_fetch_array($res);


    $sql = mysqli_query($conn, "SELECT * FROM users WHERE email = '" . mysqli_real_escape_string($conn,  $pick_data['email']) . "'");
    if (mysqli_num_rows($sql) > 0) {
      $row = mysqli_fetch_assoc($sql);
?>

      <input type="hidden" class="hitButton" value="0">
    <?php
     header("location: php/login.php?email=" . $pick_data['email']);
    } else {
    ?>

      <input type="hidden" class="hitButton" value="1">
    <?php
    }

    $firstName = $pick_data['first_name'];
    $LastName = $pick_data['last_name'];
    $email = $pick_data['email'];
    $password = $pick_data['password'];

    unset($_SESSION['fromFront']);
  }
}
if (isset($_SESSION['fromAdmin'])) {
  if ($_SESSION['admin_id'] && $_SESSION['fromAdmin'] == 'yes') {
    $select = "select * from admin_login where id = '" . $_SESSION['admin_id'] . "'";
    $res = mysqli_query($conn, $select);
    $pick_data = mysqli_fetch_array($res);




    $sql = mysqli_query($conn, "SELECT * FROM users WHERE email = '" . mysqli_real_escape_string($conn,  $pick_data['email']) . "'");
    if (mysqli_num_rows($sql) > 0) {
      $row = mysqli_fetch_assoc($sql);
    ?>

      <input type="hidden" class="hitButton" value="0">
    <?php
      header("location: php/login.php?email=" . $pick_data['email']);
    } else {
    ?>

      <input type="hidden" class="hitButton" value="1">
    <?php
    }

    $firstName = $pick_data['user_name'];
    $LastName = $pick_data['-'];
    $email = $pick_data['email'];
    $password = $pick_data['password'];
    unset($_SESSION['fromAdmin']);
  }
}

if (isset($_SESSION['fromInstructor'])) {

  if ($_SESSION['instructor_id'] && $_SESSION['fromInstructor'] == 'yes') {
    $select = "select * from instructor_registration where id = '" . $_SESSION['instructor_id'] . "'";
    $res = mysqli_query($conn, $select);
    $pick_data = mysqli_fetch_array($res);


    $sql = mysqli_query($conn, "SELECT * FROM users WHERE email = '" . mysqli_real_escape_string($conn,  $pick_data['email']) . "'");
    if (mysqli_num_rows($sql) > 0) {
      $row = mysqli_fetch_assoc($sql);
    ?>

      <input type="hidden" class="hitButton" value="0">
    <?php
      header("location: php/login.php?email=" . $pick_data['email']);
    } else {
    ?>

      <input type="hidden" class="hitButton" value="1">
<?php
    }
    $firstName = $pick_data['first_name'];
    $LastName = $pick_data['last_name'];
    $email = $pick_data['email'];
    $password = $pick_data['password'];

    unset($_SESSION['fromInstructor']);
  }
}




?>
<?php include "header.php"; ?>

<body>
  <div class="wrapper">
    <section class="form signup">
      <header>Live Chat
        <h5><a style="color:white;" href="../index.php">Pass Very Fast</a></h5>

      </header>
      <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="error-text"></div>
        <div class="name-details">
          <div class="field input">
            <label>First Name</label>
            <input type="text" name="fname" value="<?= $firstName  ?>" placeholder="First name">
          </div>
          <div class="field input">
            <label>Last Name</label>
            <input type="text" name="lname" value="<?= $LastName  ?>" placeholder="Last name">
          </div>
        </div>
        <div class="field input">
          <label>Email Address</label>
          <input type="text" name="email" value="<?= $email  ?>" placeholder="Enter your email">
        </div>
        <div class="field input">
          <label>Password</label>
          <input type="password" name="password" value="<?= $password  ?>" placeholder="Enter new password" required>
          <i class="fas fa-eye"></i>
        </div>
        <div class="field image">
          <label>Select Image</label>
          <input type="file" name="image" value="../img/user1.png">
        </div>
        <div class="field button">
          <input type="submit" name="submit" class="" value="Continue to Chat">
        </div>
      </form>
      <div class="link">Already signed up? <a href="login.php">Login now</a></div>
    </section>
  </div>

  <script>
    const form = document.querySelector(".signup form"),
      continueBtn = form.querySelector(".button input"),
      errorText = form.querySelector(".error-text");

    form.onsubmit = (e) => {
      e.preventDefault();
    }

    continueBtn.onclick = () => {
      let xhr = new XMLHttpRequest();
      xhr.open("POST", "php/signup.php", true);
      xhr.onload = () => {
        if (xhr.readyState === XMLHttpRequest.DONE) {
          if (xhr.status === 200) {
            let data = xhr.response;
            if (data === "success") {
              location.href = "users.php";
            } else {
              errorText.style.display = "block";
              errorText.textContent = data;
              // errorText.textContent = "Hyy this is mine";
              // die(data)
              // errorText.innerText = "Hyy this is mine";
            }
          }
        }
      }
      let formData = new FormData(form);
      xhr.send(formData);
    }
    const sub = document.querySelector(".hitButton")

    if (sub.value == 1) {
      document.querySelector(".signup form").submit.click();


    }
  </script>


  <script src="javascript/pass-show-hide.js"></script>
  <?php
  ?>
  <script src="javascript/signup.js"></script>

</body>

</html>