<?php
if (isset($_SESSION['unique_id'])) {
    header("location: users.php");
}

session_start();
include_once "config.php";
$email =  $_GET['email'];
if (!empty($email)) {
    $sql = mysqli_query($conn, "SELECT * FROM users WHERE email = '{$email}'");
    if (mysqli_num_rows($sql) > 0) {
        $row = mysqli_fetch_assoc($sql);
        // $user_pass = md5($password);
        // $enc_pass = $row['password'];

        $status = "Online";
        $sql2 = mysqli_query($conn, "UPDATE users SET status = '{$status}' WHERE unique_id = {$row['unique_id']}");
        if ($sql2) {
            $_SESSION['unique_id'] = $row['unique_id'];
            header("location:  ../users.php");
            echo "success";
        } else {
            echo "Something went wrong. Please try again!";
        }
    } else {
        echo "$email - This email not Exist!";
    }
} else {
    echo "All input fields are required!";
}
