Welcome to chat app

1.	Downlaod and install xampp server.
2.	Extract the file name bloodr in the htdocs folder.
3.	Run xampp server open phpmyadmin and create a database named 'chatapp'.
4.	Import the 'chat.sql' file in the database.
5.	Write this 'localhost/chat' in the url bar.
6.	That's it :)